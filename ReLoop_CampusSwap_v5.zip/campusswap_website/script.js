const $ = (id) => document.getElementById(id);
const categories = ["All","Textbooks","Lab Equipment","Electronics","Dorm Essentials","Sports Gear"];
const seedProducts = [
 {id:1,title:"Engineering Mechanics",category:"Textbooks",price:350,condition:"Good",seller:"Rahul S.",branch:"Mechanical",semester:"2nd semester",emoji:"📚",description:"Clear pages, no missing chapters. Great for exam prep.",rating:"4.9",status:"Available"},
 {id:2,title:"Scientific Calculator fx-991EX",category:"Electronics",price:850,condition:"Like New",seller:"Aarav K.",branch:"CSE",semester:"3rd semester",emoji:"🧮",description:"Fully working calculator with cover and manual.",rating:"5.0",status:"Available"},
 {id:3,title:"White Lab Coat · Size M",category:"Lab Equipment",price:220,condition:"Good",seller:"Meera P.",branch:"Biotechnology",semester:"1st semester",emoji:"🥼",description:"Clean lab coat, worn only a few times.",rating:"4.8",status:"Available"},
 {id:4,title:"A3 Drafting Board",category:"Lab Equipment",price:600,condition:"Fair",seller:"Karthik R.",branch:"Civil",semester:"2nd semester",emoji:"📐",description:"Sturdy board with parallel motion ruler.",rating:"4.7",status:"Available"},
 {id:5,title:"Data Structures in C",category:"Textbooks",price:350,condition:"Good",seller:"Rahul S.",branch:"CSE",semester:"3rd semester",emoji:"📘",description:"Useful reference for the third semester syllabus.",rating:"4.9",status:"Available"},
 {id:6,title:"Mini Desk Lamp",category:"Dorm Essentials",price:180,condition:"Like New",seller:"Sana M.",branch:"ECE",semester:"2nd semester",emoji:"💡",description:"Warm LED light, USB powered.",rating:"4.9",status:"Available"},
 {id:7,title:"Bluetooth Headphones",category:"Electronics",price:700,condition:"Good",seller:"Dev N.",branch:"CSE",semester:"4th semester",emoji:"🎧",description:"Good battery life and clear sound.",rating:"4.8",status:"Available"},
 {id:8,title:"Badminton Racket",category:"Sports Gear",price:300,condition:"Good",seller:"Ishita V.",branch:"ECE",semester:"1st semester",emoji:"🏸",description:"Lightweight racket with carry cover.",rating:"4.8",status:"Available"},
 {id:9,title:"Basic Electrical Engineering",category:"Textbooks",price:280,condition:"Fair",seller:"Arjun T.",branch:"EEE",semester:"1st semester",emoji:"📗",description:"Some highlights, otherwise in good condition.",rating:"4.7",status:"Available"},
 {id:10,title:"Scientific Drawing Set",category:"Lab Equipment",price:150,condition:"Good",seller:"Nikhil D.",branch:"Civil",semester:"1st semester",emoji:"📏",description:"Complete compass and instrument set.",rating:"4.8",status:"Available"},
 {id:11,title:"Study Table Organizer",category:"Dorm Essentials",price:120,condition:"Like New",seller:"Ananya B.",branch:"CSE",semester:"2nd semester",emoji:"🗂️",description:"Keeps stationery and notes organized.",rating:"4.9",status:"Available"},
 {id:12,title:"Football · Size 5",category:"Sports Gear",price:400,condition:"Good",seller:"Vikram J.",branch:"Mechanical",semester:"3rd semester",emoji:"⚽",description:"Good grip and shape, ready to play.",rating:"4.8",status:"Available"},
 {id:13,title:"Digital Multimeter",category:"Lab Equipment",price:450,condition:"Good",seller:"Pooja R.",branch:"EEE",semester:"3rd semester",emoji:"🔌",description:"Working multimeter with test leads.",rating:"4.9",status:"Available"},
 {id:14,title:"Laptop Stand",category:"Electronics",price:320,condition:"Like New",seller:"Sahil G.",branch:"CSE",semester:"4th semester",emoji:"💻",description:"Foldable aluminium stand.",rating:"5.0",status:"Available"},
 {id:15,title:"Hostel Storage Box",category:"Dorm Essentials",price:200,condition:"Fair",seller:"Tanya S.",branch:"ECE",semester:"2nd semester",emoji:"📦",description:"Large plastic storage box with lid.",rating:"4.6",status:"Available"},
 {id:16,title:"Calculus Workbook",category:"Textbooks",price:190,condition:"Good",seller:"Rohan P.",branch:"CSE",semester:"1st semester",emoji:"📙",description:"Practice questions with solutions.",rating:"4.8",status:"Available"},
 {id:17,title:"Safety Goggles",category:"Lab Equipment",price:90,condition:"Like New",seller:"Naveen K.",branch:"Mechanical",semester:"2nd semester",emoji:"🥽",description:"Clear protective goggles.",rating:"4.8",status:"Available"},
 {id:18,title:"Cricket Bat",category:"Sports Gear",price:550,condition:"Good",seller:"Aditya M.",branch:"Civil",semester:"3rd semester",emoji:"🏏",description:"Lightweight practice bat.",rating:"4.7",status:"Available"},
 {id:19,title:"USB Desk Fan",category:"Electronics",price:250,condition:"Good",seller:"Maya D.",branch:"ECE",semester:"2nd semester",emoji:"🌀",description:"Compact fan with adjustable speed.",rating:"4.8",status:"Available"},
 {id:20,title:"Pillow & Bedsheet Set",category:"Dorm Essentials",price:260,condition:"Good",seller:"Kiran S.",branch:"CSE",semester:"1st semester",emoji:"🛏️",description:"Freshly washed single-bed set.",rating:"4.7",status:"Available"}
];
const seedDonations = [
 {id:101,title:"First-year handwritten notes",category:"Textbooks",price:0,condition:"Good",seller:"Ananya B.",emoji:"📝",description:"Neatly organized notes for incoming students."},
 {id:102,title:"Extra stationery bundle",category:"Dorm Essentials",price:0,condition:"Like New",seller:"Rohan P.",emoji:"✏️",description:"Pens, pencils, ruler and unused notebooks."},
 {id:103,title:"Old drafting sheets",category:"Lab Equipment",price:0,condition:"Fair",seller:"Karthik R.",emoji:"📐",description:"A few spare sheets for practice."}
];
const RL = window.ReLoop;
const ui = RL.createStore({ category: "All", page: 1, lastViewed: null }); // UI state: filter, pagination, last opened item
let products = RL.storage.load("reloopProducts", seedProducts, RL.validators.isProductList);
let donations = RL.storage.load("reloopDonations", seedDonations, RL.validators.isProductList);
let user = RL.storage.load("reloopUser", null, (u) => u === null || (RL.validators.isName(u.name) && RL.auth.isSessionValid(u)));
let pendingUser = null, currentChat = null, listingStep = 1, uploadedImage = "";
let chats = RL.storage.load("reloopChats", null, RL.validators.isChatList) || [
 {id:"rahul",name:"Rahul S.",item:"Data Structures in C",messages:[{mine:false,text:"Hey! Are you interested in the Data Structures book?"},{mine:true,text:"Yes! Is it available?"},{mine:false,text:"Yes, it's available. We can meet at the Student Canteen."}]},
 {id:"meera",name:"Meera P.",item:"White Lab Coat · Size M",messages:[{mine:false,text:"Hi! The lab coat is still available."}]}
];
let soldCount = Number(localStorage.getItem("reloopSold") || 0);
function save(){
 const results=[RL.storage.save("reloopProducts",products),RL.storage.save("reloopDonations",donations),RL.storage.save("reloopChats",chats),RL.storage.save("reloopSold",soldCount)];
 if(results.some(r=>!r.ok))toast("Storage is full or unavailable. Try a smaller image.");
}
function toast(message){const el=$("toast");el.textContent=message;el.classList.add("show");setTimeout(()=>el.classList.remove("show"),2600);}
function initials(name){return (name||"Guest").split(/\s+/).slice(0,2).map(x=>x[0]).join("").toUpperCase();}
function updateUserUI(){
 const name=user?.name||"Campus guest", email=user?.email||"Sign in to get verified", verified=!!user?.verified;
 $("sidebarUser").textContent=name;$("sidebarEmail").textContent=email;$("topName").textContent=user?.name?.split(" ")[0]||"Guest";
 $("verifiedLabel").textContent=verified?"✓ Verified student":"● Guest mode";$("verifiedLabel").style.color=verified?"#28714d":"#849087";
 document.querySelectorAll(".avatar").forEach(a=>a.textContent=initials(user?.name));
 $("profileInitials").textContent=initials(user?.name);$("profileName").textContent=name;$("profileEmail").textContent=email;
 $("profileVerified").textContent=verified?"✓ Verified Student":"○ Not verified";
 $("profileListings").textContent=products.filter(p=>p.owner).length;$("profileSold").textContent=soldCount;
 $("profileLogin").textContent=verified?"Account verified":"Sign in / Register";
}
function renderProducts(list,target,options={}){
 const grid=$(target);grid.innerHTML="";
 list.forEach(p=>{
  const card=document.createElement("article");card.className="product-card";
  const image=p.image?`<img src="${p.image}" alt="${escapeHtml(p.title)}">`:`<div class="product-placeholder">${p.emoji||"📦"}</div>`;
  card.innerHTML=`<div class="product-image">${image}<span class="condition-label">${escapeHtml(p.condition||"Good")}</span><button class="save-button" title="Save item">♡</button></div><div class="product-info"><div class="product-category">${escapeHtml(p.category)}${RL.pricing.badge(p,products)}</div><h3>${escapeHtml(p.title)}</h3><div class="product-meta">${escapeHtml(p.branch||"Campus")} ${p.semester?"· "+escapeHtml(p.semester):""}</div><div class="product-bottom"><div class="product-price">${p.price===0?"FREE":"₹"+Number(p.price).toLocaleString("en-IN")} <small>${p.price===0?"":"· negotiable"}</small></div><div class="seller">★ ${p.rating||"4.8"} · ${escapeHtml(p.seller||"Student")}${RL.trust.badge(p,products)}</div></div><div class="product-actions"><button class="message-seller">Chat with seller</button><button class="mark-sold">${p.status==="Sold"?"Sold":"Mark sold"}</button></div></div>`;
  card.querySelector(".save-button").addEventListener("click",e=>{e.currentTarget.classList.toggle("saved");e.currentTarget.textContent=e.currentTarget.classList.contains("saved")?"♥":"♡";toast("Saved to your favourites (demo).");});
  card.querySelector(".message-seller").addEventListener("click",()=>openChatFor(p));
  const sold=card.querySelector(".mark-sold");if(p.status==="Sold"){sold.disabled=true;sold.textContent="Sold";}else sold.addEventListener("click",()=>{if(!user?.verified){toast("Sign in with a campus email to manage listings.");openModal("loginModal");return;}p.status="Sold";if(p.owner)soldCount++;save();renderMarket();updateUserUI();toast("Listing marked as sold.");});
  grid.appendChild(card);
 });
}
function escapeHtml(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
async function renderMarket(reset=true){
 if(reset)ui.set({page:1});
 try{
  $("resultsCount").textContent="Loading listings…";
  const r=await RL.api.queryListings(products,{query:$("searchInput").value,category:ui.get().category,sort:$("sortSelect").value,page:ui.get().page});
  renderProducts(r.items,"productGrid");
  $("resultsCount").textContent=`Showing ${r.items.length} of ${r.total} campus ${r.total===1?"find":"finds"}`;
  $("statItems").textContent=products.filter(p=>p.status!=="Sold").length;
  $("emptyState").classList.toggle("hidden",r.total!==0);
  let more=$("loadMore");
  if(!more){more=document.createElement("button");more.id="loadMore";more.type="button";more.textContent="Load more";more.className="ghost-button";more.style.cssText="display:block;margin:18px auto";more.addEventListener("click",()=>{ui.set({page:ui.get().page+1});renderMarket(false);});$("productGrid").insertAdjacentElement("afterend",more);}
  more.hidden=!r.hasMore;
  renderSimilar();
 }catch(err){toast("Could not load listings. Please refresh.");}
}
function renderDonations(){renderProducts(donations,"donationGrid");}
function renderMyListings(){renderProducts(products.filter(p=>p.owner),"myListings");}
function openModal(id){$(id).classList.remove("hidden");}
function closeModal(id){$(id).classList.add("hidden");}
function showView(view){
 document.querySelectorAll(".view").forEach(v=>v.classList.remove("active-view"));
 const map={market:"marketView",donations:"donationsView",chats:"chatsView",zones:"zonesView",profile:"profileView"};
 $(map[view]||"marketView").classList.add("active-view");
 document.querySelectorAll(".nav-link").forEach(b=>b.classList.toggle("active",b.dataset.view===view));
 const labels={market:"Marketplace",donations:"Drop & Swap",chats:"Messages",zones:"Safe exchange zones",profile:"My profile"};$("crumb").textContent=labels[view]||"Marketplace";
 if(view==="chats")renderChats();if(view==="profile"){renderMyListings();updateUserUI();}
 window.scrollTo({top:0,behavior:"smooth"});
}
function startLogin(){
 const email=$("loginEmail").value.trim().toLowerCase(),name=$("loginName").value.trim();
 if(!RL.validators.isName(name)){toast("Please enter your full name (letters only).");return;}
 if(!RL.validators.isCampusEmail(email)){toast("Use an email ending in @campus.edu or @univ.ac.in.");return;}
 pendingUser={name,email,branch:$("loginBranch").value,verified:false};RL.auth.start();closeModal("loginModal");$("otpInput").value="";$("otpError").textContent="";openModal("otpModal");
}
function verifyOtp(){
 const r=RL.auth.check($("otpInput").value);
 if(!r.ok){
  const messages={expired:"Code expired. Please sign in again.",locked:"Too many attempts. Please sign in again.",none:"Please start sign-in first.",wrong:`Incorrect code. ${r.left} attempt(s) left.`};
  $("otpError").textContent=messages[r.reason]||"Invalid code.";return;
 }
 user={...pendingUser,verified:true,verifiedAt:Date.now()};RL.storage.save("reloopUser",user);closeModal("otpModal");updateUserUI();toast("You're verified! Welcome to ReLoop.");showView("market");
}
function openChatFor(p){
 if(!user?.verified){toast("Sign in with your campus email to message sellers.");openModal("loginModal");return;}
 let c=chats.find(x=>x.item===p.title);
 if(!c){c={id:"chat"+Date.now(),name:p.seller||"Student seller",item:p.title,messages:[{mine:false,text:`Hi! Thanks for your interest in ${p.title}. What would you like to know?`}]};chats.unshift(c);save();}
 showView("chats");renderChats();selectChat(c.id);
}
function renderChats(){
 $("conversationList").innerHTML="";
 chats.forEach(c=>{const b=document.createElement("button");b.className="conversation"+(c.id===currentChat?" active":"");b.innerHTML=`<span class="conv-avatar">${initials(c.name)}</span><span><strong>${escapeHtml(c.name)}</strong><small>${escapeHtml(c.item)}</small></span>`;b.onclick=()=>selectChat(c.id);$("conversationList").appendChild(b);});
 $("chatTotal").textContent=chats.length;$("messageCount").textContent=chats.length;
 if(currentChat&&!chats.some(c=>c.id===currentChat))currentChat=null;
 if(!currentChat&&chats.length)currentChat=chats[0].id;
 if(currentChat)renderChatPanel();
}
function selectChat(id){currentChat=id;renderChats();document.querySelectorAll(".conversation").forEach((b,i)=>b.classList.toggle("active",chats[i]?.id===id));}
function renderChatPanel(){
 const c=chats.find(x=>x.id===currentChat);if(!c)return;
 $("chatPanel").innerHTML=`<div class="chat-head"><span class="avatar">${initials(c.name)}</span><div><strong>${escapeHtml(c.name)}</strong><small>About: ${escapeHtml(c.item)} · Campus member</small></div></div><div class="chat-messages" id="chatMessages">${c.messages.map(m=>`<div class="bubble ${m.mine?"mine":""}">${escapeHtml(m.text)}${m.card?`<div class="zone-card"><strong>📍 ${escapeHtml(m.card.name)}</strong><span>${escapeHtml(m.card.note)}</span></div>`:""}${!m.mine&&RL.safety.assess(m.text).level!=="low"?`<span class="risk-flag">⚠ ${escapeHtml(RL.safety.assess(m.text).reasons[0])}</span>`:""}<span class="bubble-time">${m.mine?"You":"Seller"} · just now</span></div>`).join("")}</div><form class="chat-compose" id="chatCompose"><input id="chatInput" placeholder="Write a message or make an offer..." autocomplete="off" required><button type="button" id="suggestZone" class="ghost-button">📍 Safe spot</button><button type="submit">Send ↗</button></form>`;
 $("chatCompose").addEventListener("submit",e=>{e.preventDefault();const value=$("chatInput").value.trim();if(!value)return;const risk=RL.safety.assess(value);
  if(risk.level==="high"&&!confirm("⚠ "+risk.reasons.join(" ")+"\n\nSend anyway?"))return;
  if(risk.level==="medium")toast("Safety tip: "+risk.reasons[0]);
  c.messages.push({mine:true,text:value});save();renderChatPanel();$("chatMessages").scrollTop=$("chatMessages").scrollHeight;});
 $("suggestZone").addEventListener("click",()=>{
  const names=[...document.querySelectorAll("[data-zone]")].map(b=>b.dataset.zone);
  const name=RL.safezone.nextZone(names,c);
  if(!name){toast("No safe zones available.");return;}
  c.messages.push(RL.safezone.buildMessage(name));save();renderChatPanel();$("chatMessages").scrollTop=$("chatMessages").scrollHeight;
 });
}
function resetListing(){
 $("listingForm").reset();uploadedImage="";$("imagePreview").innerHTML='▧ <span>Image preview will appear here</span>';listingStep=1;setListingStep(1);
}
function setListingStep(n){
 listingStep=n;document.querySelectorAll(".listing-step").forEach(el=>el.classList.toggle("active",Number(el.dataset.step)===n));
 [1,2,3].forEach(i=>$("step"+i+"dot").classList.toggle("active",i<=n));
 $("prevStep").classList.toggle("hidden",n===1);$("nextStep").classList.toggle("hidden",n===3);$("publishItem").classList.toggle("hidden",n!==3);
}
function validateStep(){
 const result=RL.validators.validateListing({title:$("itemTitle").value,price:$("itemPrice").value});
 const field=listingStep===1?"title":listingStep===2?"price":null;
 if(field&&result.errors[field]){toast(result.errors[field]);return false;}
 return true;
}
function openListing(donation=false){
 if(!user?.verified){toast("Please verify your campus email first.");openModal("loginModal");return;}
 resetListing();$("itemPrice").value=donation?"0":"";$("listingModal").dataset.donation=donation?"yes":"no";openModal("listingModal");
}
function updateReview(){
 const title=escapeHtml($("itemTitle").value),price=Number($("itemPrice").value||0);
 $("listingReview").innerHTML=`${uploadedImage?`<img src="${uploadedImage}">`:`<div style="width:95px;height:95px;background:#e8efe4;border-radius:7px;display:grid;place-items:center;font-size:35px">📦</div>`}<div><div class="product-category">${escapeHtml($("itemCategory").value)}</div><h3>${title}</h3><strong>₹${price.toLocaleString("en-IN")}</strong><p>${escapeHtml($("itemCondition").value)} · ${escapeHtml($("itemBranch").value||user.branch)} · ${escapeHtml($("itemSemester").value||"Campus")}</p></div>`;
 const tip=$("priceTip");tip.textContent=price>1000?"✦ Price tip: compare with the original retail price. Campus resale listings are often around 50% of retail.":"✦ Fair-trade guide: used campus items are often listed around 50% of original retail price.";
}
function publishListing(e){
 e.preventDefault();if(listingStep!==3)return;
 const check=RL.validators.validateListing({title:$("itemTitle").value,price:$("itemPrice").value});
 if(!check.ok){toast(Object.values(check.errors)[0]);return;}
 const isDonation=$("listingModal").dataset.donation==="yes";
 const item={id:Date.now(),title:$("itemTitle").value.trim(),category:$("itemCategory").value,price:Number($("itemPrice").value),condition:$("itemCondition").value,seller:user.name,branch:$("itemBranch").value||user.branch,semester:$("itemSemester").value,description:$("itemDescription").value,image:uploadedImage,emoji:"📦",status:"Available",owner:true,rating:"5.0"};
 if(isDonation||item.price===0){item.price=0;donations.unshift(item);}else products.unshift(item);
 save();closeModal("listingModal");renderMarket();renderDonations();renderMyListings();updateUserUI();showView(isDonation||item.price===0?"donations":"market");toast("Your item has been published!"); 
}
document.querySelectorAll(".nav-link").forEach(b=>b.addEventListener("click",()=>showView(b.dataset.view)));
document.querySelectorAll("[data-view]").forEach(b=>{if(!b.classList.contains("nav-link"))b.addEventListener("click",()=>showView(b.dataset.view));});
$("heroSell").onclick=()=>openListing(false);$("profileAdd").onclick=()=>openListing(false);$("donateButton").onclick=()=>openListing(true);
$("openLogin").onclick=()=>openModal("loginModal");$("profileLogin").onclick=()=>{if(!user?.verified)openModal("loginModal");else toast("You're already verified on this browser.");};
$("topProfile").onclick=()=>showView("profile");$("topChat").onclick=()=>showView("chats");
$("loginForm").addEventListener("submit",e=>{e.preventDefault();startLogin();});$("verifyOtp").onclick=verifyOtp;
document.querySelectorAll("[data-close]").forEach(b=>b.onclick=()=>closeModal(b.dataset.close));
document.querySelectorAll(".modal-backdrop").forEach(back=>back.addEventListener("click",e=>{if(e.target===back)closeModal(back.id);}));
$("searchInput").addEventListener("input",renderMarket);$("sortSelect").addEventListener("change",renderMarket);
$("categoryFilters").addEventListener("click",e=>{const b=e.target.closest("[data-category]");if(!b)return;ui.set({category:b.dataset.category});document.querySelectorAll(".category-chip").forEach(x=>x.classList.toggle("selected",x===b));renderMarket();});
$("allItems").onclick=()=>{ui.set({category:"All"});$("searchInput").value="";document.querySelectorAll(".category-chip").forEach(x=>x.classList.toggle("selected",x.dataset.category==="All"));renderMarket();};
$("resetFilters").onclick=()=>{$("searchInput").value="";ui.set({category:"All"});document.querySelectorAll(".category-chip").forEach(x=>x.classList.toggle("selected",x.dataset.category==="All"));renderMarket();};
document.querySelectorAll("[data-scroll]").forEach(b=>b.onclick=()=>$("listings").scrollIntoView({behavior:"smooth"}));
$("itemImage").addEventListener("change",e=>{const file=e.target.files[0];if(!file)return;if(file.size>3*1024*1024){toast("Please choose an image smaller than 3 MB.");e.target.value="";return;}const reader=new FileReader();reader.onload=()=>{uploadedImage=reader.result;$("imagePreview").innerHTML=`<img src="${uploadedImage}" alt="Selected item preview">`;};reader.readAsDataURL(file);});
$("nextStep").onclick=()=>{if(!validateStep())return;if(listingStep===2)updateReview();setListingStep(Math.min(3,listingStep+1));};
$("prevStep").onclick=()=>setListingStep(Math.max(1,listingStep-1));$("listingForm").addEventListener("submit",publishListing);
document.querySelectorAll("[data-zone]").forEach(b=>b.onclick=()=>toast(`${b.dataset.zone}: recommended public meetup location.`));
renderMarket();renderDonations();updateUserUI();renderChats();

// Price suggestion shown in the review step of the listing flow
const baseUpdateReview=updateReview;
updateReview=function(){
 baseUpdateReview();
 analyzeImage();
 const s=RL.search.suggestPrice($("itemCategory").value,$("itemCondition").value);
 if(s&&$("listingModal").dataset.donation!=="yes")$("priceTip").textContent=`✦ Suggested range for this category and condition: ₹${s.low}–₹${s.high}.`;
};

// Expire the simulated session while the page is open
setInterval(()=>{
 if(user&&!RL.auth.isSessionValid(user)){user=null;RL.storage.remove("reloopUser");updateUserUI();toast("Session expired. Please sign in again.");}
},60000);

// "You might also like": similar listings shown under the marketplace after a listing is opened
function renderSimilar(){
 let wrap=$("similarWrap");
 if(!wrap){
  wrap=document.createElement("section");wrap.id="similarWrap";wrap.innerHTML='<h2 class="similar-title"></h2><div id="similarGrid"></div>';
  $("loadMore").insertAdjacentElement("afterend",wrap);$("similarGrid").className=$("productGrid").className;
 }
 const viewed=ui.get().lastViewed,list=viewed?RL.recommend.similar(viewed,products):[];
 wrap.hidden=!list.length;
 if(list.length){wrap.querySelector("h2").textContent=`You might also like (similar to ${viewed.title})`;renderProducts(list,"similarGrid");}
}
const baseOpenChatFor=openChatFor;
openChatFor=function(p){ui.set({lastViewed:p});baseOpenChatFor(p);renderSimilar();};

// Connectivity feedback
window.addEventListener("offline",()=>toast("You're offline. Your data stays saved on this device."));
window.addEventListener("online",()=>toast("Back online."));

// Keep the category chips in sync with the store, whichever handler changed the category
ui.subscribe(state=>document.querySelectorAll(".category-chip").forEach(x=>x.classList.toggle("selected",x.dataset.category===state.category)));

// Photos: compress, hash, warn about look-alike listings, and keep the hash on the published item
let uploadedHash=null;
async function analyzeImage(){
 uploadedHash=null;
 if(!uploadedImage)return;
 try{
  const out=await RL.imagehash.process(uploadedImage);
  uploadedImage=out.dataUrl;uploadedHash=out.hash;
  const dup=RL.imagehash.findDuplicate(out.hash,products.concat(donations));
  if(dup)toast(`⚠ This photo looks like an existing listing: "${dup.title}".`);
 }catch(err){/* keep the original image */}
}
$("listingForm").addEventListener("submit",()=>{
 const newest=products.concat(donations).reduce((a,b)=>(!a||b.id>a.id?b:a),null);
 if(uploadedHash&&newest&&Date.now()-newest.id<2000){newest.imageHash=uploadedHash;save();}
});
