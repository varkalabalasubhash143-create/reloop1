/* Content-based recommendations: TF-IDF vectors + cosine similarity, nudged by price closeness. */
(function (root) {
  const RL = (root.ReLoop = root.ReLoop || {});
  const tokens = (s) => String(s || "").toLowerCase().split(/[^a-z0-9]+/).filter((w) => w.length > 1);
  const docText = (p) => [p.title, p.title, p.category, p.branch, p.semester, p.description].join(" "); // title counts double

  function buildVectors(list) {
    const docs = list.map((p) => tokens(docText(p)));
    const df = new Map();
    docs.forEach((d) => new Set(d).forEach((w) => df.set(w, (df.get(w) || 0) + 1)));
    const idf = (w) => Math.log((list.length + 1) / ((df.get(w) || 0) + 1)) + 1;
    return docs.map((d) => {
      const tf = new Map();
      d.forEach((w) => tf.set(w, (tf.get(w) || 0) + 1));
      const vec = new Map();
      let norm = 0;
      tf.forEach((count, w) => { const x = (1 + Math.log(count)) * idf(w); vec.set(w, x); norm += x * x; });
      norm = Math.sqrt(norm) || 1;
      vec.forEach((x, w) => vec.set(w, x / norm)); // unit length, so dot product = cosine
      return vec;
    });
  }

  function cosine(a, b) {
    const [small, large] = a.size < b.size ? [a, b] : [b, a];
    let sum = 0;
    small.forEach((x, w) => { const y = large.get(w); if (y) sum += x * y; });
    return sum;
  }

  function similar(item, list, count = 4) {
    const pool = list.filter((p) => p.status !== "Sold");
    const all = pool.some((p) => p.id === item.id) ? pool : pool.concat(item);
    const vectors = buildVectors(all);
    const self = all.findIndex((p) => p.id === item.id);
    return all
      .map((p, i) => {
        if (i === self) return { p, s: -1 };
        const gap = item.price > 0 && p.price > 0 ? Math.abs(p.price - item.price) / Math.max(p.price, item.price) : 0;
        return { p, s: cosine(vectors[self], vectors[i]) * (1 - 0.3 * gap) };
      })
      .filter((x) => x.s > 0.05)
      .sort((a, b) => b.s - a.s)
      .slice(0, count)
      .map((x) => x.p);
  }

  RL.recommend = { tokens, buildVectors, cosine, similar };
})(typeof window !== "undefined" ? window : globalThis);
