/* Tiny observable store: one place for UI state, with subscriptions instead of scattered globals. */
(function (root) {
  const RL = (root.ReLoop = root.ReLoop || {});

  RL.createStore = function createStore(initial) {
    let state = { ...initial };
    const listeners = new Set();
    return {
      get: () => state,
      set(patch) {
        const changed = Object.keys(patch).some((k) => state[k] !== patch[k]);
        if (!changed) return state;
        state = { ...state, ...patch };
        listeners.forEach((fn) => fn(state));
        return state;
      },
      subscribe(fn) {
        listeners.add(fn);
        return () => listeners.delete(fn);
      },
    };
  };
})(typeof window !== "undefined" ? window : globalThis);
