/* Input validation and schema checks. Used for forms AND for data read back from localStorage. */
(function (root) {
  const RL = (root.ReLoop = root.ReLoop || {});

  const isCampusEmail = (e) =>
    typeof e === "string" && /^[a-z0-9._%+-]+@(campus\.edu|univ\.ac\.in)$/.test(e.trim().toLowerCase());
  const isName = (n) => typeof n === "string" && /^[\p{L} .'-]{2,60}$/u.test(n.trim());
  const isOtp = (o) => /^\d{6}$/.test(String(o).trim());

  function validateListing({ title, price }) {
    const errors = {};
    const t = String(title || "").trim();
    if (!t) errors.title = "Please enter an item name.";
    else if (t.length > 120) errors.title = "Item name must be 120 characters or fewer.";
    const p = Number(price);
    if (price === "" || price == null || !Number.isFinite(p) || p < 0 || p > 100000)
      errors.price = "Enter a valid price between 0 and 100000.";
    return { ok: Object.keys(errors).length === 0, errors };
  }

  const isProduct = (p) =>
    !!p && typeof p === "object" && Number.isFinite(p.id) &&
    typeof p.title === "string" && p.title.trim() !== "" && p.title.length <= 120 &&
    Number.isFinite(p.price) && p.price >= 0 && p.price <= 100000 &&
    (p.image === undefined || p.image === "" || /^data:image\//.test(p.image));
  const isProductList = (a) => Array.isArray(a) && a.every(isProduct);

  const isChat = (c) =>
    !!c && typeof c.id === "string" && typeof c.name === "string" && Array.isArray(c.messages) &&
    c.messages.every((m) => m && typeof m.mine === "boolean" && typeof m.text === "string" &&
      (m.card === undefined || (m.card && m.card.type === "zone" && typeof m.card.name === "string")));
  const isChatList = (a) => Array.isArray(a) && a.every(isChat);

  RL.validators = { isCampusEmail, isName, isOtp, validateListing, isProduct, isProductList, isChatList };
})(typeof window !== "undefined" ? window : globalThis);
