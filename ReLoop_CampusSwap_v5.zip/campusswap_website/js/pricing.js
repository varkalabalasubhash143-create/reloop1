/* Deal detection with a robust statistic: median and MAD (median absolute deviation) of comparable listings. */
(function (root) {
  const RL = (root.ReLoop = root.ReLoop || {});

  function median(values) {
    const s = [...values].sort((a, b) => a - b), mid = s.length >> 1;
    return s.length % 2 ? s[mid] : (s[mid - 1] + s[mid]) / 2;
  }

  // Needs at least 3 comparable listings in the same category, otherwise there is no fair baseline.
  function dealScore(item, list) {
    if (!(item.price > 0)) return null;
    const prices = list.filter((p) => p.id !== item.id && p.category === item.category && p.price > 0 && p.status !== "Sold").map((p) => p.price);
    if (prices.length < 3) return null;
    const med = median(prices);
    const mad = median(prices.map((x) => Math.abs(x - med))) || med * 0.1;
    const z = (0.6745 * (item.price - med)) / mad; // modified z-score
    const label = z <= -1 ? "great" : z <= -0.4 ? "good" : z >= 1.5 ? "high" : "fair";
    return { label, z: Math.round(z * 100) / 100, median: med };
  }

  function badge(item, list) {
    const d = dealScore(item, list);
    return d && d.label === "great" ? " · 🔥 Great deal" : d && d.label === "good" ? " · 👍 Good price" : "";
  }

  RL.pricing = { median, dealScore, badge };
})(typeof window !== "undefined" ? window : globalThis);
