/* Seller trust signal derived from a seller's listings, ratings and completed sales. */
(function (root) {
  const RL = (root.ReLoop = root.ReLoop || {});

  function sellerStats(seller, list) {
    const mine = list.filter((p) => p.seller === seller);
    const ratings = mine.map((p) => Number(p.rating)).filter(Number.isFinite);
    const avgRating = ratings.length ? ratings.reduce((a, b) => a + b, 0) / ratings.length : 0;
    return { listings: mine.length, sold: mine.filter((p) => p.status === "Sold").length, avgRating };
  }

  function isTrusted(seller, list) {
    const s = sellerStats(seller, list);
    return (s.listings >= 2 && s.avgRating >= 4.7) || s.sold >= 2;
  }

  const badge = (item, list) => (isTrusted(item.seller, list) ? " · ✔ Trusted" : "");

  RL.trust = { sellerStats, isTrusted, badge };
})(typeof window !== "undefined" ? window : globalThis);
