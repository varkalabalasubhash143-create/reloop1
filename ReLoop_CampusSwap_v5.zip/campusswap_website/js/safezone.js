/* Safe-zone suggestions that become real data cards inside a chat conversation. */
(function (root) {
  const RL = (root.ReLoop = root.ReLoop || {});
  const NOTE = "Public, well-lit spot. Meet in daylight and bring a friend if you can.";

  // Cycles through the zones so repeated suggestions offer a different place each time.
  function nextZone(zoneNames, chat) {
    const zones = [...new Set(zoneNames)].filter(Boolean);
    if (!zones.length) return null;
    const used = chat.messages.filter((m) => m.card && m.card.type === "zone").length;
    return zones[used % zones.length];
  }

  const buildMessage = (name) => ({ mine: true, text: `Let's meet at ${name}.`, card: { type: "zone", name, note: NOTE } });

  RL.safezone = { nextZone, buildMessage, NOTE };
})(typeof window !== "undefined" ? window : globalThis);
