/* Safe localStorage wrapper: never throws, validates what it reads, reports write failures. */
(function (root) {
  const RL = (root.ReLoop = root.ReLoop || {});

  function load(key, fallback, validate) {
    try {
      const raw = root.localStorage.getItem(key);
      if (raw == null) return fallback;
      const value = JSON.parse(raw);
      if (validate && !validate(value)) {
        root.localStorage.removeItem(key); // tampered or outdated data
        return fallback;
      }
      return value;
    } catch (err) {
      return fallback;
    }
  }

  function save(key, value) {
    try {
      root.localStorage.setItem(key, JSON.stringify(value));
      return { ok: true };
    } catch (err) {
      return { ok: false, error: err && err.name === "QuotaExceededError" ? "quota" : "unavailable" };
    }
  }

  function remove(key) {
    try { root.localStorage.removeItem(key); } catch (err) { /* ignore */ }
  }

  RL.storage = { load, save, remove };
})(typeof window !== "undefined" ? window : globalThis);
