/* Relevance-ranked search (weighted, typo-tolerant), price suggestions and similar items. */
(function (root) {
  const RL = (root.ReLoop = root.ReLoop || {});
  const words = (s) => String(s || "").toLowerCase().split(/[^a-z0-9]+/).filter(Boolean);

  // true when two words differ by at most one insertion, deletion or substitution
  function withinOneEdit(a, b) {
    if (Math.abs(a.length - b.length) > 1) return false;
    let i = 0, j = 0, diff = 0;
    while (i < a.length && j < b.length) {
      if (a[i] === b[j]) { i++; j++; continue; }
      if (++diff > 1) return false;
      if (a.length > b.length) i++; else if (a.length < b.length) j++; else { i++; j++; }
    }
    return diff + (a.length - i) + (b.length - j) <= 1;
  }

  function score(item, query) {
    const tokens = words(query);
    if (!tokens.length) return 0;
    const title = words(item.title);
    const fields = [[title, 5], [words(item.category), 2], [words(item.branch), 2], [words(item.description), 1]];
    let total = 0;
    for (const t of tokens) {
      let best = 0;
      for (const [list, weight] of fields) {
        for (const w of list) {
          if (w === t) best = Math.max(best, weight);
          else if (w.startsWith(t)) best = Math.max(best, weight * 0.7);
          else if (t.length >= 4 && withinOneEdit(w, t)) best = Math.max(best, weight * 0.5);
        }
      }
      if (!best) return 0; // every search word must match something
      total += best;
    }
    return total;
  }

  function rank(list, { query = "", category = "All", sort = "" } = {}) {
    let out = list
      .filter((p) => p.status !== "Sold" && (category === "All" || p.category === category))
      .map((p) => ({ p, s: score(p, query) }))
      .filter((x) => !words(query).length || x.s > 0);
    if (words(query).length && !["low", "high", "newest"].includes(sort)) out.sort((a, b) => b.s - a.s);
    out = out.map((x) => x.p);
    if (sort === "low") out.sort((a, b) => a.price - b.price);
    if (sort === "high") out.sort((a, b) => b.price - a.price);
    if (sort === "newest") out.sort((a, b) => b.id - a.id);
    return out;
  }

  const RETAIL = { Textbooks: 600, "Lab Equipment": 500, Electronics: 1500, "Dorm Essentials": 400, "Sports Gear": 800 };
  const CONDITION = { "Like New": 0.6, Good: 0.45, Fair: 0.3 };

  function suggestPrice(category, condition) {
    const base = RETAIL[category], factor = CONDITION[condition];
    if (!base || !factor) return null;
    const round10 = (n) => Math.round(n / 10) * 10;
    return { low: round10(base * factor * 0.85), high: round10(base * factor * 1.15) };
  }

  function similar(item, list, count = 4) {
    const titleWords = words(item.title);
    return list
      .filter((p) => p.id !== item.id && p.status !== "Sold")
      .map((p) => {
        let s = 0;
        if (p.category === item.category) s += 3;
        if (p.branch && p.branch === item.branch) s += 2;
        s += words(p.title).filter((w) => titleWords.includes(w)).length;
        if (item.price > 0 && Math.abs(p.price - item.price) / item.price <= 0.3) s += 1;
        return { p, s };
      })
      .filter((x) => x.s > 0)
      .sort((a, b) => b.s - a.s)
      .slice(0, count)
      .map((x) => x.p);
  }

  RL.search = { score, rank, suggestPrice, similar };
})(typeof window !== "undefined" ? window : globalThis);
