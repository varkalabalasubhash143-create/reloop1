/* Photo handling: client-side compression plus a perceptual difference hash (dHash) to catch duplicate listings. */
(function (root) {
  const RL = (root.ReLoop = root.ReLoop || {});

  // gray: 72 luminance values (9 columns x 8 rows). Each bit says "is this pixel brighter than its right neighbour".
  function dHashFromGray(gray) {
    let hex = "";
    for (let nibble = 0; nibble < 16; nibble++) {
      let v = 0;
      for (let b = 0; b < 4; b++) {
        const bit = nibble * 4 + b, row = Math.floor(bit / 8), col = bit % 8;
        v = (v << 1) | (gray[row * 9 + col] > gray[row * 9 + col + 1] ? 1 : 0);
      }
      hex += v.toString(16);
    }
    return hex;
  }

  function hamming(a, b) {
    let dist = 0;
    for (let i = 0; i < a.length; i++) {
      let x = parseInt(a[i], 16) ^ parseInt(b[i], 16);
      while (x) { dist += x & 1; x >>= 1; }
    }
    return dist;
  }

  function findDuplicate(hash, list, maxDistance = 6) {
    let best = null, bestDist = Infinity;
    for (const p of list) {
      if (!p.imageHash || p.imageHash.length !== hash.length) continue;
      const d = hamming(hash, p.imageHash);
      if (d <= maxDistance && d < bestDist) { best = p; bestDist = d; }
    }
    return best;
  }

  // Browser only: shrink to <=640px JPEG (saves localStorage space) and hash a 9x8 grayscale thumbnail.
  function process(dataUrl, { maxSide = 640, quality = 0.7 } = {}) {
    return new Promise((resolve, reject) => {
      if (typeof document === "undefined") return reject(new Error("no DOM"));
      const img = new Image();
      img.onerror = () => reject(new Error("bad image"));
      img.onload = () => {
        const scale = Math.min(1, maxSide / Math.max(img.width, img.height));
        const canvas = document.createElement("canvas");
        canvas.width = Math.max(1, Math.round(img.width * scale));
        canvas.height = Math.max(1, Math.round(img.height * scale));
        canvas.getContext("2d").drawImage(img, 0, 0, canvas.width, canvas.height);
        const thumb = document.createElement("canvas");
        thumb.width = 9; thumb.height = 8;
        const ctx = thumb.getContext("2d");
        ctx.drawImage(img, 0, 0, 9, 8);
        const px = ctx.getImageData(0, 0, 9, 8).data, gray = [];
        for (let i = 0; i < px.length; i += 4) gray.push(0.299 * px[i] + 0.587 * px[i + 1] + 0.114 * px[i + 2]);
        resolve({ dataUrl: canvas.toDataURL("image/jpeg", quality), hash: dHashFromGray(gray) });
      };
      img.src = dataUrl;
    });
  }

  RL.imagehash = { dHashFromGray, hamming, findDuplicate, process };
})(typeof window !== "undefined" ? window : globalThis);
