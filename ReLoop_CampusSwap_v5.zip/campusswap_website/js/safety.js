/* Rule-based scam-risk scoring for chat messages. */
(function (root) {
  const RL = (root.ReLoop = root.ReLoop || {});
  const RULES = [
    { re: /\b(otp|cvv|password|pin)\b/i, weight: 4, reason: "Never share OTPs, PINs or passwords." },
    { re: /\b(advance|token amount|pay (me )?first|before (we )?meet(ing)?|western union|wire transfer)\b/i, weight: 3, reason: "Asks for payment before meeting." },
    { re: /(https?:\/\/|www\.|\b\w+\.(ly|link)\/)/i, weight: 2, reason: "Contains an external link." },
    { re: /\b(whatsapp|telegram|signal|call me|dm me)\b/i, weight: 1, reason: "Moves the chat off ReLoop." },
    { re: /\b(urgent|immediately|right now|last chance|today only)\b/i, weight: 1, reason: "Creates pressure to act fast." },
  ];

  function assess(text) {
    const hits = RULES.filter((r) => r.re.test(String(text || "")));
    const score = hits.reduce((sum, r) => sum + r.weight, 0);
    return { score, level: score >= 4 ? "high" : score >= 2 ? "medium" : "low", reasons: hits.map((r) => r.reason) };
  }

  RL.safety = { assess };
})(typeof window !== "undefined" ? window : globalThis);
