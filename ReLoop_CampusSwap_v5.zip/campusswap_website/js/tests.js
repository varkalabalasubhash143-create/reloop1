/* Dependency-free tests. Open tests.html in a browser (or run in Node) to see results. */
(function (root) {
  const RL = root.ReLoop;
  const pending = [], results = [];
  const test = (name, fn) => pending.push(
    Promise.resolve().then(fn).then(() => results.push({ name, ok: true }), (e) => results.push({ name, ok: false, msg: e.message })));
  const eq = (a, b) => { if (JSON.stringify(a) !== JSON.stringify(b)) throw new Error(`expected ${JSON.stringify(b)}, got ${JSON.stringify(a)}`); };
  const ok = (c, m) => { if (!c) throw new Error(m || "assertion failed"); };
  const V = RL.validators, A = RL.auth, S = RL.search;
  const item = (id, title, category, price, extra = {}) => ({ id, title, category, price, ...extra });

  test("email: accepts campus domains", () => { ok(V.isCampusEmail("rahul@campus.edu")); ok(V.isCampusEmail("A.B@univ.ac.in")); });
  test("email: rejects look-alike domains", () => {
    ["a@campus.edu.evil.com", "@campus.edu", "x@gmail.com", "x y@campus.edu", "", null].forEach((e) => ok(!V.isCampusEmail(e), String(e)));
  });
  test("name and otp format", () => { ok(V.isName("Rahul Sharma")); ok(!V.isName("<b>")); ok(V.isOtp("246810")); ok(!V.isOtp("12ab56")); });
  test("listing validation", () => {
    ok(V.validateListing({ title: "Book", price: "100" }).ok);
    ok(V.validateListing({ title: "Free", price: "0" }).ok);
    ok(!V.validateListing({ title: " ", price: "1" }).ok);
    ok(!V.validateListing({ title: "x", price: "-5" }).ok);
    ok(!V.validateListing({ title: "x", price: "" }).ok);
    ok(!V.validateListing({ title: "x", price: "999999" }).ok);
  });
  test("schema rejects tampered products", () => {
    ok(V.isProduct(item(1, "Book", "Textbooks", 10)));
    ok(!V.isProduct(item(1, "Book", "Textbooks", "10")));
    ok(!V.isProduct(item(1, "Book", "Textbooks", 10, { image: "javascript:alert(1)" })));
    ok(!V.isProductList("nope"));
  });
  test("otp: correct code passes once issued", () => { A.start(0); eq(A.check("246810", 1000).ok, true); });
  test("otp: wrong code counts attempts and then locks", () => {
    A.start(0);
    eq(A.check("000000", 1).left, 4);
    for (let i = 0; i < 4; i++) A.check("000000", 2);
    eq(A.check("246810", 3).reason, "locked");
  });
  test("otp: expires after 5 minutes", () => { A.start(0); eq(A.check("246810", 6 * 60 * 1000).reason, "expired"); });
  test("session: expires after 24 hours and needs verifiedAt", () => {
    const u = { email: "a@campus.edu", verified: true, verifiedAt: 0 };
    ok(A.isSessionValid(u, 1000)); ok(!A.isSessionValid(u, 25 * 3600 * 1000));
    ok(!A.isSessionValid({ email: "a@campus.edu", verified: true }, 1)); ok(!A.isSessionValid(null));
  });
  test("storage: corrupt JSON falls back", () => {
    root.localStorage.setItem("t1", "{not json"); eq(RL.storage.load("t1", "fb"), "fb");
  });
  test("storage: failed schema check falls back and clears key", () => {
    root.localStorage.setItem("t2", JSON.stringify([{ id: "x" }]));
    eq(RL.storage.load("t2", "fb", V.isProductList), "fb"); eq(root.localStorage.getItem("t2"), null);
  });
  test("storage: save reports failure instead of throwing", () => {
    const real = root.localStorage.setItem;
    root.localStorage.setItem = () => { const e = new Error("full"); e.name = "QuotaExceededError"; throw e; };
    const r = RL.storage.save("k", 1); root.localStorage.setItem = real; eq(r, { ok: false, error: "quota" });
  });
  const list = [item(1, "Scientific Calculator", "Electronics", 850), item(2, "Lab Coat", "Lab Equipment", 220),
    item(3, "Calculus Workbook", "Textbooks", 190), item(4, "Old Lamp", "Dorm Essentials", 100, { status: "Sold" })];
  test("search: hides sold items and filters category", () => {
    eq(S.rank(list).map((p) => p.id), [1, 2, 3]); eq(S.rank(list, { category: "Textbooks" }).map((p) => p.id), [3]);
  });
  test("search: ranks title matches first", () => { eq(S.rank(list, { query: "calculator" })[0].id, 1); });
  test("search: tolerates a one-letter typo", () => { eq(S.rank(list, { query: "calculater" })[0].id, 1); });
  test("search: unknown word returns nothing", () => { eq(S.rank(list, { query: "zzzzzz" }).length, 0); });
  test("search: sorts by price", () => {
    eq(S.rank(list, { sort: "low" }).map((p) => p.price), [220, 190, 850].sort((a, b) => a - b));
    eq(S.rank(list, { sort: "high" })[0].id, 1);
  });
  test("price suggestion", () => { const s = S.suggestPrice("Textbooks", "Good"); ok(s.low < s.high); eq(S.suggestPrice("x", "Good"), null); });
  test("similar items exclude self and sold", () => {
    const ids = S.similar(list[0], list).map((p) => p.id); ok(!ids.includes(1) && !ids.includes(4));
  });
  test("api: paginates results", async () => {
    const big = Array.from({ length: 20 }, (_, i) => item(i + 1, "Item " + i, "Textbooks", i));
    const p1 = await RL.api.queryListings(big, { page: 1 }), p3 = await RL.api.queryListings(big, { page: 3 });
    eq(p1.items.length, 8); eq(p1.hasMore, true); eq(p3.items.length, 20); eq(p3.hasMore, false);
  });

  test("safe zone: cycles through zones and builds a card message", () => {
    const chat = { messages: [] }, zones = ["Library", "Cafeteria", "Library"];
    eq(RL.safezone.nextZone(zones, chat), "Library");
    const msg = RL.safezone.buildMessage("Library"); eq(msg.card.type, "zone"); chat.messages.push(msg);
    eq(RL.safezone.nextZone(zones, chat), "Cafeteria"); eq(RL.safezone.nextZone([], chat), null);
  });
  test("schema accepts zone cards and rejects malformed ones", () => {
    const base = { id: "c", name: "A", messages: [RL.safezone.buildMessage("Library")] };
    ok(V.isChatList([base])); ok(!V.isChatList([{ ...base, messages: [{ mine: true, text: "x", card: { type: "evil" } }] }]));
  });
  test("trust: needs repeat sellers with good ratings, or completed sales", () => {
    const l = [item(1, "A", "Textbooks", 1, { seller: "Ria", rating: "4.9" }), item(2, "B", "Textbooks", 1, { seller: "Ria", rating: "4.8" }),
      item(3, "C", "Textbooks", 1, { seller: "Sam", rating: "5.0" })];
    ok(RL.trust.isTrusted("Ria", l)); ok(!RL.trust.isTrusted("Sam", l)); eq(RL.trust.badge(l[2], l), "");
    ok(RL.trust.isTrusted("Zed", [item(4, "D", "x", 1, { seller: "Zed", status: "Sold" }), item(5, "E", "x", 1, { seller: "Zed", status: "Sold" })]));
  });

  test("store: notifies only on real changes and can unsubscribe", () => {
    const st = RL.createStore({ a: 1 }); let calls = 0; const off = st.subscribe(() => calls++);
    st.set({ a: 1 }); eq(calls, 0); st.set({ a: 2 }); eq(calls, 1); eq(st.get().a, 2); off(); st.set({ a: 3 }); eq(calls, 1);
  });
  test("store: state is replaced, not mutated", () => {
    const st = RL.createStore({ a: 1 }), before = st.get(); st.set({ a: 2 }); eq(before.a, 1);
  });

  const docs = [item(1, "Data Structures in C", "Textbooks", 350, { branch: "CSE", description: "algorithms reference book" }),
    item(2, "Algorithms Handbook", "Textbooks", 320, { branch: "CSE", description: "algorithms and data structures" }),
    item(3, "Badminton Racket", "Sports Gear", 300, { branch: "ECE", description: "lightweight racket" }),
    item(4, "Cricket Bat", "Sports Gear", 550, { branch: "Civil", description: "practice bat" })];
  test("recommend: TF-IDF finds the topically similar item first", () => { eq(RL.recommend.similar(docs[0], docs)[0].id, 2); });
  test("recommend: excludes the item itself and sold items", () => {
    const ids = RL.recommend.similar(docs[0], docs.map((p) => (p.id === 2 ? { ...p, status: "Sold" } : p))).map((p) => p.id);
    ok(!ids.includes(1) && !ids.includes(2));
  });
  test("recommend: cosine of identical vectors is 1", () => { const v = RL.recommend.buildVectors([docs[0], docs[0]]); ok(Math.abs(RL.recommend.cosine(v[0], v[1]) - 1) < 1e-9); });
  const lab = [220, 600, 450, 150, 90].map((p, i) => item(i + 1, "Lab " + i, "Lab Equipment", p));
  test("pricing: flags a cheap item as a great deal", () => { eq(RL.pricing.dealScore(lab[4], lab).label, "great"); });
  test("pricing: flags an expensive item as high and needs 3 comparables", () => {
    eq(RL.pricing.dealScore(item(9, "X", "Lab Equipment", 2000), lab).label, "high");
    eq(RL.pricing.dealScore(lab[0], lab.slice(0, 3)), null); eq(RL.pricing.dealScore(item(8, "Free", "Lab Equipment", 0), lab), null);
  });
  test("pricing: median handles odd and even counts", () => { eq(RL.pricing.median([3, 1, 2]), 2); eq(RL.pricing.median([4, 1, 3, 2]), 2.5); });
  test("safety: flags OTP requests and advance payment as high risk", () => {
    eq(RL.safety.assess("send your OTP now").level, "high");
    eq(RL.safety.assess("pay first, then we meet").level, "medium");
    eq(RL.safety.assess("pay advance and visit www.deal.com").level, "high");
  });
  test("safety: normal messages stay low risk", () => { eq(RL.safety.assess("Is it still available? Can we meet at the library?").level, "low"); });
  const grad = Array.from({ length: 72 }, (_, i) => (i % 9) * 10), inv = grad.map((v) => 80 - v);
  test("imagehash: identical images have distance 0, inverted images are far apart", () => {
    const a = RL.imagehash.dHashFromGray(grad); eq(a.length, 16); eq(RL.imagehash.hamming(a, a), 0);
    ok(RL.imagehash.hamming(a, RL.imagehash.dHashFromGray(inv)) > 32);
  });
  test("imagehash: small brightness change keeps the hash, duplicates are found", () => {
    const a = RL.imagehash.dHashFromGray(grad), b = RL.imagehash.dHashFromGray(grad.map((v) => v + 5));
    ok(RL.imagehash.hamming(a, b) <= 6);
    eq(RL.imagehash.findDuplicate(b, [item(1, "Old", "x", 1, { imageHash: a })]).id, 1);
    eq(RL.imagehash.findDuplicate(b, [item(2, "Other", "x", 1, { imageHash: RL.imagehash.dHashFromGray(inv) })]), null);
  });

  Promise.all(pending).then(() => {
    RL.testResults = results;
    const failed = results.filter((r) => !r.ok);
    if (typeof document !== "undefined") {
      const out = document.getElementById("results");
      out.innerHTML = `<h2>${results.length - failed.length}/${results.length} tests passed</h2>` +
        results.map((r) => `<div class="${r.ok ? "pass" : "fail"}">${r.ok ? "PASS" : "FAIL"} - ${r.name}${r.ok ? "" : ": " + r.msg}</div>`).join("");
    } else {
      results.forEach((r) => console.log((r.ok ? "PASS " : "FAIL ") + r.name + (r.msg ? " :: " + r.msg : "")));
      console.log(`${results.length - failed.length}/${results.length} passed`);
      process.exitCode = failed.length ? 1 : 0;
    }
  });
})(typeof window !== "undefined" ? window : globalThis);
