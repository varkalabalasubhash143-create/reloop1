# Architecture

```
index.html / style.css
        |
    script.js  (UI: views, rendering, event wiring)  <--  js/store.js (UI state, subscriptions)
        |
   js/api.js   (async data-access seam: query + pagination)
     |      |
 search.js recommend.js pricing.js safety.js imagehash.js trust.js safezone.js     (pure logic, no DOM)
        |
 js/storage.js (safe, schema-checked localStorage)   js/auth.js (OTP + session rules)
        |
 js/validators.js (forms and stored-data schemas)
```

- **Pure logic modules** never touch the DOM, so they run in the browser and in Node and are covered by `tests.html`.
- **`api.js` is the only place the UI asks for listings.** Replacing localStorage with a REST backend means changing
  `api.js` and `storage.js`; the UI keeps calling the same async functions.
- **State flow:** user action -> `ui.set(...)` or data change -> `renderMarket()` -> `api.queryListings()` -> DOM.
- **Known limits (HTML/CSS/JS-only brief):** data lives in the browser, auth is simulated, and no server verifies anything.
